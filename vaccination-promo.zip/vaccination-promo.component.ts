import { Component } from '@angular/core';

@Component({
  selector: 'app-vaccination-promo',
  templateUrl: './vaccination-promo.component.html',
  styleUrls: ['./vaccination-promo.component.css']
})
export class VaccinationPromoComponent {}
