
import { Component } from '@angular/core';

@Component({
  selector: 'app-children-vaccination',
  templateUrl: './children-vaccination.component.html',
  styleUrls: ['./children-vaccination.component.css']
})
export class ChildrenVaccinationComponent {}
