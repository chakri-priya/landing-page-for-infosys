import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  activeTab: string = 'district';
  selectedState: string = '';
  selectedDistrict: string = '';
  pinCode: string = '';

  states: string[] = ['State 1', 'State 2'];
  districts: { [key: string]: string[] } = {
    'State 1': ['District A', 'District B'],
    'State 2': ['District C', 'District D']
  };

  searchByDistrict() {
    console.log(`Searching by District: ${this.selectedState}, ${this.selectedDistrict}`);
  }

  searchByPin() {
    console.log(`Searching by PIN: ${this.pinCode}`);
  }
}